(function () {
  // The width and height of the captured photo. We will set the
  // width to the value defined here, but the height will be
  // calculated based on the aspect ratio of the input stream.

  var width = 1000;    // We will scale the photo width to this
  var height = 1000;     // This will be computed based on the input stream

  // |streaming| indicates whether or not we're currently streaming
  // video from the camera. Obviously, we start at false.

  var streaming = false;

  // The various HTML elements we need to configure or control. These
  // will be set by the startup() function.

  var video = null;
  var canvas = null;
  var photo = null;
  var startbutton = null;

  // Replace <Subscription Key> with your valid subscription key.
  var subscriptionKey = "";
  var uriBase = "https://centralindia.api.cognitive.microsoft.com/face/v1.0";
  var personGroupId = "dxc_crm_users_one";
  var faceIds = [];


  function startup() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    photo = document.getElementById('photo');
    startbutton = document.getElementById('startbutton');
    registerBtn = document.getElementById('registerBtn');
    loginBtn = document.getElementById('loginBtn');

    navigator.mediaDevices.getUserMedia({ video: true, audio: false })
      .then(function (stream) {
        video.srcObject = stream;
        video.play();
      })
      .catch(function (err) {
        console.log("An error occurred: " + err);
      });

    video.addEventListener('canplay', function (ev) {
      if (!streaming) {
        height = video.videoHeight / (video.videoWidth / width);

        // Firefox currently has a bug where the height can't be read from
        // the video, so we will make assumptions if this happens.

        if (isNaN(height)) {
          height = width / (4 / 3);
        }

        video.setAttribute('width', width);
        video.setAttribute('height', height);
        canvas.setAttribute('width', width);
        canvas.setAttribute('height', height);
        streaming = true;
      }
    }, false);

    startbutton.addEventListener('click', function (ev) {
      takepicture();
      ev.preventDefault();
    }, false);

    registerBtn.addEventListener('click', function (ev) {
      Register();
      ev.preventDefault();
    }, false);
    loginBtn.addEventListener('click', function (ev) {
      Login();
      ev.preventDefault();
    }, false);

    clearphoto();
  }

  // Fill the photo with an indication that none has been
  // captured.

  function clearphoto() {
    var context = canvas.getContext('2d');
    context.fillStyle = "#AAA";
    context.fillRect(0, 0, canvas.width, canvas.height);

    var data = canvas.toDataURL('image/png');
    photo.setAttribute('src', data);
  }

  // Capture a photo by fetching the current contents of the video
  // and drawing it into a canvas, then converting that to a PNG
  // format data URL. By drawing it on an offscreen canvas and then
  // drawing that to the screen, we can change its size and/or apply
  // other changes before drawing it.

  function takepicture() {
    var context = canvas.getContext('2d');
    if (width && height) {
      canvas.width = width;
      canvas.height = height;
      context.drawImage(video, 0, 0, width, height);

      var data = canvas.toDataURL('image/png');
      photo.setAttribute('src', data);

      fetch(data)
      .then(res => res.blob())
      .then(blobData => {
        // attach blobData as the data for the post request
        detectFace(blobData);
      });

      // getBlobData(data).then(data =>{
      //   detectFace(data);
      // });
    } else {
      clearphoto();
    }
  }

  function getBlobData(data) {
    var data = canvas.toDataURL('image/png');
    fetch(data)
      .then(res => res.blob())
      .then(blobData => {
        // attach blobData as the data for the post request
        return blobData;
      });
  }

  function Register(){
    CreatePerson();
    //CreatePersonGroup();
  }
  function Login(){
    PersonIdentify();
  }

  function detectFace(blobData) {
    // NOTE: You must use the same region in your REST call as you used to
    // obtain your subscription keys. For example, if you obtained your
    // subscription keys from westus, replace "westcentralus" in the URL
    // below with "westus".
    //
    // Free trial subscription keys are generated in the "westus" region.
    // If you use a free trial subscription key, you shouldn't need to change 
    // this region.

    // Request parameters.
    var params = {
      "returnFaceId": "true",
      "returnFaceLandmarks": "false",
      "returnFaceAttributes":
        "age,gender,headPose,smile,facialHair,glasses,emotion," +
        "hair,makeup,occlusion,accessories,blur,exposure,noise"
    };

    // Perform the REST API call.
    $.ajax({
      url: uriBase + "/detect?" + $.param(params),

      // Request headers.
      beforeSend: function (xhrObj) {
        xhrObj.setRequestHeader("Content-Type", "application/octet-stream");
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },

      type: "POST",
      processData: false,
      // Request body.
      data: blobData,
    })

      .done(function (data) {
        // Show formatted JSON on webpage.
        $("#responseTextArea").val(JSON.stringify(data, null, 2));
        faceIds=[];
        faceIds.push(data[0].faceId);
      })

      .fail(function (jqXHR, textStatus, errorThrown) {
        // Display error message.
        var errorString = (errorThrown === "") ?
          "Error. " : errorThrown + " (" + jqXHR.status + "): ";
        errorString += (jqXHR.responseText === "") ?
          "" : (jQuery.parseJSON(jqXHR.responseText).message) ?
            jQuery.parseJSON(jqXHR.responseText).message :
            jQuery.parseJSON(jqXHR.responseText).error.message;
        alert(errorString);
      });
  }

  function CreatePersonGroup() {
    var params = {
      personGroupId : personGroupId,
    };

    var data = {
      "name": "DXCCRMUsers"
    };

    $.ajax({
      url: uriBase + "/persongroups/" + personGroupId,
      beforeSend: function (xhrObj) {
        // Request headers
        xhrObj.setRequestHeader("Content-Type", "application/json");
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },
      type: "PUT",
      // Request body
      data: JSON.stringify(data),
    })
      .done(function (data) {
        alert("success");
        CreatePerson();
      })
      .fail(function () {
        alert("error");
      });
  }

  function CreatePerson() {
    debugger;
    var data = {
      "name": "Person 1"
    };

    $.ajax({
      url: uriBase + "/persongroups/" + personGroupId + "/persons",
      beforeSend: function (xhrObj) {
        // Request headers
        xhrObj.setRequestHeader("Content-Type", "application/json");
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },
      type: "POST",
      // Request body
      data: JSON.stringify(data),
    })
      .done(function (resData) {
        alert("success");
      
      var data = canvas.toDataURL('image/png');
      fetch(data)
      .then(res => res.blob())
      .then(blobData => {
        // attach blobData as the data for the post request
        AddFace(resData.personId, blobData);
      });

      })
      .fail(function () {
        alert("error");
      });
  }

  function AddFace(personId,blobData) {
    debugger;
    var params = {
      // Request parameters
      "personGroupId" : personGroupId,
      "personId": personId
    };

    $.ajax({
      url: uriBase + "/persongroups/" + personGroupId + "/persons/" + personId + "/persistedFaces?" + $.param(params),
      beforeSend: function (xhrObj) {
        // Request headers
        xhrObj.setRequestHeader("Content-Type", "application/octet-stream");
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },
      type: "POST",
      // Request body
      data: blobData,
      processData: false,
    })
      .done(function (data) {
        alert("success");
        TrainPersonGroup();
      })
      .fail(function () {
        alert("error");
      });
  }

  function TrainPersonGroup() {
    debugger;

    var params = {
      // Request parameters
    };

    $.ajax({
      url: uriBase + "/persongroups/" + personGroupId + "/train?" + $.param(params),
      beforeSend: function (xhrObj) {
        // Request headers
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },
      type: "POST",
      // Request body
      data: null,
    })
      .done(function (data) {
        alert("success");
      })
      .fail(function () {
        alert("error");
      });
  }

  function PersonIdentify() {
    var params = {
      // Request parameters
    };

    var data = {
      "personGroupId": personGroupId,
      "faceIds": faceIds,
      "maxNumOfCandidatesReturned": 1,
      "confidenceThreshold": 0.5
    }

    $.ajax({
      url: uriBase + "/identify?" + $.param(params),
      beforeSend: function (xhrObj) {
        // Request headers
        xhrObj.setRequestHeader("Content-Type", "application/json");
        xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);
      },
      type: "POST",
      // Request body
      data: JSON.stringify(data),
    })
      .done(function (data) {
        alert("success");
        $("#responseTextArea").val(JSON.stringify(data, null, 2));
      })
      .fail(function () {
        alert("error");
        $("#responseTextArea").val(JSON.stringify(data, null, 2));
      });
  }

  // Set up our event listener to run the startup process
  // once loading is complete.
  window.addEventListener('load', startup, false);
})();
